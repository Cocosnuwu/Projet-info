#include <math.h>
#include <unistd.h>
#include "fonction.h"


void setting_parameters() {
    Player newplayer;
  Ranking rank;
  int sizemax_ps;
    int p;
    int size, different, check;
    bool verifblocage;
    int i, k;
    newplayer.score=0;
    
do {
    printf("╔════════════════════════════════════════════════╗\n"
           "║                                                ║\n"
           "║             Donnez votre pseudo :              ║\n"
           "║                                                ║\n"
           "║                                                ║\n"
           "║                                                ║\n"
           "╚════════════════════════════════════════════════╝\n");
    for (p = 0; p < 20; p++) {
        newplayer.nickname[p] = 0;
    }
    scanf("%s", newplayer.nickname);
    sizemax_ps = strlen(newplayer.nickname);
    empty_buffer();
} while (sizemax_ps <= 0 || sizemax_ps > 20);

  
    do {
      printf("Entrez la size du table (entre 5 et 20) : ");
      check=scanf("%d", &size);
      empty_buffer();
    } while (size < 5 || size > 20 || check!=1);
    
    do {
        printf("Entrez le nombre de forme différentes (entre 4 et 6) : ");
        check=scanf("%d", &different);
        empty_buffer();
    } while (different < 4 || different > 6 || check!=1);
    
    
    square_table tab[20][20]; // Définition du table
    
    srand(time(NULL)); // Génération aléatoire
    
    
    for (i = 0; i < size; i++) {
        for (k = 0; k < size; k++) {
        // Génération aléatoire des caractères
        tab[i][k].character = 'A' + rand() % different; //  symboles différents choisit lors du scanf
        tab[i][k].variable = 0; // variable à zéro pour le compteur
      }
    }
    Displaymoji(tab, size);        //début du jeu
    replacement(tab, size, different, newplayer);

      do{ 
  
      
    printf("Votre score est de : %ld \n",newplayer.score);                                     
    Displaymoji(tab, size);        
    exchange(tab,size);            //échange
    newplayer.score=replacement(tab, size, different,newplayer );
    verifblocage=detectionblocage(tab,size);
    
    }while(verifblocage==0);
    Displaymoji(tab, size);
//a remplacé par le compteur temp
  printf("Temps de jeu du joueur : ");
    scanf("%d", &newplayer.timeplay);
    empty_buffer();
    printf("Score du joueur : ");
    scanf("%ld", &newplayer.score);
    empty_buffer();
  printf("c'est terminé plus aucun mouvement n'est possible\nVoici votre score %ld et le classement\n",newplayer.score);
  rank = SavePlayer(rank, newplayer);
    AfficherRanking(rank);
}

////////////////////////////////////////////////////////////////////////////////////////////



void Home_menu(){
  
  char selection=0;                      // Valeur nécessaire pour rentrer dans la boucle while
  
  printf("\x1b[34m----------------------------------\n");
  printf("\x1b[34m--------------------------------\n");
  printf("\n");

  printf("\x1b[32mBienvenue sur CY - Crush ! :D\n ");        // Message d'accueil
  
  printf("\n");
  printf("\x1b[34m--------------------------------\n");  
  printf("\x1b[34m----------------------------------\n");
  printf(COLOR("%d"),0);

  printf("\n \n");

  printf("\x1b[32m1." "\x1B[36mNouvelle partie\n\n");               // Interface Menu muni de 4 options
  printf("\x1b[32m2." "\x1B[36mReprendre\n\n");
  printf("\x1b[32m3." "\x1B[36mCrédits\n\n");
  printf("\x1B[31m4. Quitter le jeu\n\n\n");
  printf(COLOR("%d"),0);
  
  
 // while (selection<1 || selection>4) {

  do{
    
    printf("\x1B[33mVeuillez entrer" "\x1B[32m [1]" "\x1B[33m," " \x1B[32m[2]" "\x1B[33," "\x1B[32m [3]" "\x1B[33m ou " "\x1B[31m[4]" "\x1B[33m :\n" );         // Demande à l'utilisateur de faire son choix
    printf(COLOR("%d"),0);
    scanf("%s", &selection);              // Récuperation de la réponse du joueur
    if (selection=='1'){
      
      printf("\x1B[33mC'est parti pour une nouvelle aventure ! \n");     // Lancement d'une nouvelle sauvegarde
      printf(COLOR("%d"),0);
      setting_parameters();
    }

    else if (selection=='2') {
      
      printf("\x1B[33mHeureux de te retrouver, on est reparti !\n" );      // Lancement d'une sauvegarde précédente
      printf(COLOR("%d"),0);
      resume_game();
    }

    else if (selection=='3') {
      
      printf("\x1B[33mCy Crush par :\n\n\n" "\x1B[34mBLUTEAU Corentin\n\n" "\x1B[32mLY Athyna\n\n" "\x1B[36mANDRIANAVALONA Timothé\n\n");                   // Display des crédits
      printf(COLOR("%d"),0);
      selection=5;                                   // Retour au début de la boucle, redemande choix du joueur

      
    }

    else if (selection=='4') {
      
      printf("\x1B[33mSalut, j'espère qu'on se reverra très bientôt ! :D\n");     // message d'au revoir, sayonara !
      printf(COLOR("%d"),0);
      exit(0);
    }

    else {
      
      printf("\x1B[31mVeuillez réessayer x(\n");    // Valeur entrée non valide --> retour au début de la boucle
      printf(COLOR("%d"),0);
    }
  }while ((selection!= '4') || (selection!= '3') || (selection!= '2') || (selection!= 1));

}