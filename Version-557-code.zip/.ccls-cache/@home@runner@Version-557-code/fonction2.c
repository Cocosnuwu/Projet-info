#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h> //pour les booléens

#define COLOR(X) "\x1b["X"m"    //macro pour ajouter la couleur facilement, le X est l'emplacement du code couleur, au forma "nombre"
typedef struct square_table {
    char character;
    bool variable;
    int different;
} square_table;






void Displaymoji(square_table tab[][20],int size){ // Display du table à modifier pendant la séance d'info
    int i,j,k,l,m,p;
        for(i=0;i<size;i++){
            printf("\n \n");
            if(i==0){
                printf(" ");
                for(m=0;m<size;m++){        //Display des chiffres en hauteur
                  if(m<10){  
                    printf("   %d.",m);
                  }
                  if(m==10){
                    printf("   %d.",m);  
                  }
                  else if(m>10){
                    printf("  %d.",m);  
                  }
                }
                printf("\n");      
            }
            
            for (l = 0; l < size; l++) {
              if (l == 0) {
                    printf("  +----"); // Ligne de fin de séparation
                }
              if (l == size - 1) {
                    printf("+----+\n"); // Ligne de fin de séparation
                }
                else if(l<size -1&& l!=0){
                printf("+----"); // Ligne à multiplier de séparation
                }
            }
                for(k=0;k<size;k++){
                    if(k==0){
                      if(i<10){  
                        printf(" %d",i);
                      }
                      if(i==10){
                        printf("%d",i);  
                      }
                      else if(i>10){
                        printf("%d",i);  
                      }
                   
            }
            if(tab[i][k].variable==1){
                printf("|");
                printf("\x1b[31m O ");
                printf(COLOR("%d"),0);
                
            }
            else if(tab[i][k].character=='A'){
                printf("|");
                printf(" 🍐 ");
                
            }
            else if(tab[i][k].character=='B'){
                printf("|");
                printf(" 🍉 ");
            }
            else if(tab[i][k].character=='C'){
                printf("|");
                printf(" 🥝 ");
                
            }
            else if(tab[i][k].character=='D'){
                printf("|");
                printf(" 🍇 ");
                
            }
            else if(tab[i][k].character=='E'){
                printf("|");
                printf(" 🧁 ");
                printf(COLOR("%d"),0);
            }
            else if(tab[i][k].character=='F'){
                printf("|");
                printf(" 🥕 ");
                printf(COLOR("%d"),0);
            }
        }
        printf("|"); // Barre de fin
    } 
    printf("\n");
    printf(" ");
    for (p = 0; p < size; p++) {
      if (p == 0) {
                    printf(" "); // Ligne de fin de séparation
                }
      if (p == size - 1) {
            printf("+----+\n"); // Ligne de fin de séparation
        } 
      else if(p<size -1){
          printf("+----"); // Ligne à multiplier de séparation
        }
    }
}

bool detect_mark(square_table tab[][20],int size,bool verif_quick) {
    int ol, oc; // optimisation fin du k en ligne et colonne
    bool verif = 0;
    verif_quick = 0; // booléen pour vérifier qu'il ne reste aucune ligne ou colonne de 3 ou plus
    int i, j, k, l, m, o;
    
    for (int i = 0; i < size; i++) {
        ol=size;
        for (int j = 0; j < ol; j++) {
            if(j==0){
                oc=size;
                int counter = 1; // initialisation des counters à 1
                int counterlow=1;
                while (counter < size && tab[i][counter].character == tab[i][j].character) {
                counter++; // compter le nombre d'éléments égaux vers la droite
                }
                while (size-counterlow >=0 && tab[i][size - counterlow].character == tab[i][0].character) {
                counterlow++; // compter le nombre d'éléments égaux vers la droite
                }
                if (counter >= 3&&counterlow<=1) { // si on a trouvé une série d'au moins 3 éléments égaux
                    for (int k = 0; k < counter; k++) {
                        tab[i][k].variable=1; // remplacer les éléments par des "O"
                    }
                    verif_quick=1;
                }
                if ((counterlow >= 3&&counter<=1)){
                    tab[i][0].variable=1; // remplacer du premier éléments par un "O"
                    for (int k = size+1-counterlow; k < size ; k++) {
                        tab[i][k].variable=1; // remplacer les éléments par des "O"
                    }
                    ol=size-counterlow; //optimisation fin de ligne
                    verif_quick=1;
                }
                if (counterlow+counter>=4&&counter>=1&&counterlow>=1){
                    for (int k = 0; k < counter; k++) {
                        tab[i][k].variable=1; // remplacer les éléments par des "O"
                    }
                    for (int k = size + 1 - counterlow; k<size ; k++) {
                        tab[i][k].variable=1; // remplacer les éléments par des "O"
                    }
                    ol=size-counterlow; //optimisation fin de ligne
                    verif_quick=1;
                }
            }
            if(i==0){
                int counter = 1; // réinitialisation des counters à 1
                int counterlow=1; 
                while (size-counterlow >=0 && tab[size - counterlow][j].character == tab[i][j].character) {
                counterlow++; // compter le nombre d'éléments égaux vers la droite
                }
                while (counter < size && tab[i + counter][j].character == tab[i][j].character) {
                    counter++; // compter le nombre d'éléments égaux vers le bas
                }
                if (counter >= 3&&counterlow==1) { // si on a trouvé une série d'au moins 3 éléments égaux
                    for (int k = 0; k < counter; k++) {
                        tab[k][j].variable=1; // remplacer les éléments par des "O"
                        verif_quick=1;
                        
                    }
                }
                if (counterlow >= 3&&counter==1){
                    tab[0][j].variable=1; // remplacer du premier éléments par un "O"
                    for (int k = size+1-counterlow; k <size ; k++) {
                        tab[k][j].variable=1; // remplacer les éléments par des "O"
                        verif_quick=1;
                        
                    }
                oc=size-counterlow;
                }
                if (counterlow+counter>=4&&counter!=1&&counterlow!=1){
                    for (int k = 0; k < counter; k++) {
                        tab[k][j].variable=1; // remplacer les éléments par des "O"
                    }
                    for (int k = size+1 -counterlow; k < size; k++) {
                        tab[k][j].variable=1; // remplacer les éléments par des "O"
                       
                    }
                oc=size-counterlow; //optimisation fin de ligne
                verif_quick=1;
                }
            }
            int counter = 1; // initialisation du counter à 1
            while (j + counter < size && tab[i][j + counter].character == tab[i][j].character) {
                counter++; // compter le nombre d'éléments égaux vers la droite
            }
            if (counter >= 3) { // si on a trouvé une série d'au moins 3 éléments égaux
                for (int k = 0; k < counter; k++) {
                    tab[i][j+k].variable=1; // remplacer les éléments par des "O"
                }
            }
            counter = 1; // réinitialisation du counter à 1
            while (i + counter < size && tab[i + counter][j].character == tab[i][j].character) {
                counter++; // compter le nombre d'éléments égaux vers le bas
            }
            if (counter >= 3) { // si on a trouvé une série d'au moins 3 éléments égaux
                for (int k = 0; k < counter; k++) {
                    tab[i+k][j].variable=1; // remplacer les éléments par des "O"
                }
            }
        
        
        
            for (int j = 0; j < size; j++) {
                int counter = 1; // initialisation du counter à 1
                while (j + counter < size && tab[i][j + counter].character == tab[i][j].character) {
                    counter++; // compter le nombre d'éléments égaux vers la droite
                }
                if (counter >= 3) { // si on a trouvé une série d'au moins 3 éléments égaux
                    for (int k = 0; k < counter; k++) {
                        tab[i][j+k].variable=1; // remplacer les éléments par des "O"
                    }
                    verif_quick=1;
                }
                counter = 1; // réinitialisation du counter à 1
                while (i + counter < size && tab[i + counter][j].character == tab[i][j].character) {
                    counter++; // compter le nombre d'éléments égaux vers le bas
                }
                if (counter >= 3) { // si on a trouvé une série d'au moins 3 éléments égaux
                    for (int k = 0; k < counter; k++) {
                        tab[i+k][j].variable=1; // remplacer les éléments par des "O"
                    }
                    verif_quick=1;
                }
            }
        }        
    }
    return verif_quick;
}

void move_left(square_table tab[][20],int size) {
    int i,j,k;
    bool verif=0;
    
    
    
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            if (tab[i][j].variable == 1) {
                k = j;
                while (k > 0 && tab[i][k - 1].variable == 0) {
                    // Échanger le caractère (avec son booléen précédent!!!!)
                    char tempcharacter = tab[i][k - 1].character;
                    int tempVariable = tab[i][k - 1].variable;
                    tab[i][k - 1].character = tab[i][k].character;
                    tab[i][k - 1].variable = tab[i][k].variable;
                    tab[i][k].character = tempcharacter;
                    tab[i][k].variable = tempVariable;
                    k--;
                }
            }
        }
    }


    

}





void empty_buffer(){         //pour vérifier les scanfs
  while(getchar()!='\n'){
  }
}


void exchange(square_table tab[][20],int size){
  int a1, b1, a2, b2;    //a1 : ligne de la 1ère square à échanger et b1 : colonne de cette 1ère square
                         // pareil pour a2 et b2
  a1=0;
  b1=0;
  a2=0;
  b2=0;
  int temp, check;
  int i, k;
  square_table tabcopie[20][20]; 
  bool verif_quick;
  verif_quick=0;
    for (i = 0; i < size; i++) {
        for (k = 0; k < size; k++) {
        tabcopie[i][k].character = tab[i][k].character;
        tabcopie[i][k].variable = tab[i][k].variable;
        }
    }
  
  //boucle pour recommencer après chaque échange  
  int erreur=0; 
    char square1, square2;
do{
    
    do{  //pour vérifier l'inverse : on veut que les a et b soient compris entre 0 et _ inclus
      printf("\nDonnez les coordonnées de la 1ère case : ligne, puis colonne\n"); 
      check=scanf("%d",&a1);
      check=scanf("%d",&b1);
      empty_buffer();
    }while (a1<0 || a1>=size || b1<0 || b1>=size || check!=1);
    
    square1=tabcopie[a1][b1].character;
    
    printf("square1: ");
    if(square1=='A'){
      printf(" 🍐 \n");
    }
    else if(square1=='B'){
      printf(" 🍉 \n");
    }
    else if(square1=='C'){
      printf(" 🥝 \n");
    }
    else if(square1=='D'){
      printf(" 🍇 \n");               
    }
    else if(square1=='E'){
      printf(" 🧁 \n");
      //printf(COLOR("%d"),0);
    }
    else if(square1=='F'){
      printf(" 🥕 \n");
      //printf(COLOR("%d"),0);
    }


    do{
      printf("\nDonnez les coordonnées de la 2nd case : ligne, puis colonne\n");
      check=scanf("%d",&a2);
      check=scanf("%d",&b2);
      empty_buffer();
    }while (a2<0 || a2>=size || b2<0 || b2>=size || check!=1);
    
    square2=tabcopie[a2][b2].character;

    printf("square2: ");
    if(square2=='A'){
      printf(" 🍐 \n");
    }
    else if(square2=='B'){
      printf(" 🍉 \n");
    }
    else if(square2=='C'){
      printf(" 🥝 \n");
    }
    else if(square2=='D'){
      printf(" 🍇 \n");               
    }
    else if(square2=='E'){
      printf(" 🧁 \n");
      //printf(COLOR("%d"),0);
    }
    else if(square2=='F'){
      printf(" 🥕 \n");
      //printf(COLOR("%d"),0);
    }





    
  if (((a1==a2)&&((b1==b2+1)||(b1==b2-1))) || ((b1==b2)&&((a1==a2+1)||(a1==a2-1)))){  //condition pour vérifier que les squares soient à côtés ou au-dessus/dessous
    printf("condition ok\n");
    square1=tabcopie[a2][b2].character;    //échange de la square1 par la square2
    square2=tabcopie[a1][b1].character;    //pareil mais pour square2 par square1
    temp=tabcopie[a1][b1].character;
    tabcopie[a1][b1].character=tabcopie[a2][b2].character;
    tabcopie[a2][b2].character=temp;
    verif_quick=detect_mark(tabcopie, size, verif_quick);

    if(verif_quick==1){
      printf("case1 échangée: ");
        if(square1=='A'){
          printf(" 🍐 \n");
        }
        else if(square1=='B'){
          printf(" 🍉 \n");
        }
        else if(square1=='C'){
          printf(" 🥝 \n");
        }
        else if(square1=='D'){
          printf(" 🍇 \n");               
        }
        else if(square1=='E'){
          printf(" 🧁 \n");
          
        }
        else if(square1=='F'){
          printf(" 🥕 \n");
         
      }
    

      printf("case2 échangée: ");
        if(square2=='A'){
          printf(" 🍐 \n");
        }
        else if(square2=='B'){
          printf(" 🍉 \n");
        }
        else if(square2=='C'){
          printf(" 🥝 \n");
        }
        else if(square2=='D'){
          printf(" 🍇 \n");               
        }
        else if(square2=='E'){
          printf(" 🧁 \n");
          
        }
        else if(square2=='F'){
          printf(" 🥕 \n");
        
        }
    
    }


    
    
  }
  else if((a1==a2)&&((b1==0 && b2==size-1)||(b1==size-1 && b2==0))){    //condition spéciale où les 2 squares à échanger sont aux extrêmités de la même ligne
    printf("ok ligne\n");  //pour vérifier cette codition
    square1=tabcopie[a2][b2].character;    //échange de la square1 par la square2
    square2=tabcopie[a1][b1].character;    //pareil mais pour square2 par square1
    temp=tabcopie[a1][b1].character;
    tabcopie[a1][b1].character=tabcopie[a2][b2].character;
    tabcopie[a2][b2].character=temp;
    verif_quick=detect_mark(tabcopie, size, verif_quick);
if(verif_quick==1){
      printf("square1 échangée: ");
        if(square1=='A'){
          printf(" 🍐 \n");
        }
        else if(square1=='B'){
          printf(" 🍉 \n");
        }
        else if(square1=='C'){
          printf(" 🥝 \n");
        }
        else if(square1=='D'){
          printf(" 🍇 \n");               
        }
        else if(square1=='E'){
          printf(" 🧁 \n");
          
        }
        else if(square1=='F'){
          printf(" 🥕 \n");
         
      }
    

      printf("square2 échangée: ");
        if(square2=='A'){
          printf(" 🍐 \n");
        }
        else if(square2=='B'){
          printf(" 🍉 \n");
        }
        else if(square2=='C'){
          printf(" 🥝 \n");
        }
        else if(square2=='D'){
          printf(" 🍇 \n");               
        }
        else if(square2=='E'){
          printf(" 🧁 \n");
          
        }
        else if(square2=='F'){
          printf(" 🥕 \n");
        
        }
    
    }



    
  }
  else if((b1==b2)&&((a1==0 && a2==size-1)||(a1==size-1 && a2==0))){ //condition spéciale où les 2 squares à échanger sont aux extrêmités de la même colonne
    printf("ok colonne\n");
    square1=tabcopie[a2][b2].character;    //échange de la square1 par la square2
    square2=tabcopie[a1][b1].character;    //pareil mais pour square2 par square1
    temp=tabcopie[a1][b1].character;
    tabcopie[a1][b1].character=tabcopie[a2][b2].character;
    tabcopie[a2][b2].character=temp;
    verif_quick=detect_mark(tabcopie, size, verif_quick);
    if(verif_quick==1){
      printf("square1 échangée: ");
        if(square1=='A'){
          printf(" 🍐 \n");
        }
        else if(square1=='B'){
          printf(" 🍉 \n");
        }
        else if(square1=='C'){
          printf(" 🥝 \n");
        }
        else if(square1=='D'){
          printf(" 🍇 \n");               
        }
        else if(square1=='E'){
          printf(" 🧁 \n");
         
        }
        else if(square1=='F'){
          printf(" 🥕 \n");
         
      }
    

      printf("square2 échangée: ");
        if(square2=='A'){
          printf(" 🍐 \n");
        }
        else if(square2=='B'){
          printf(" 🍉 \n");
        }
        else if(square2=='C'){
          printf(" 🥝 \n");
        }
        else if(square2=='D'){
          printf(" 🍇 \n");               
        }
        else if(square2=='E'){
          printf(" 🧁 \n");
          
        }
        else if(square2=='F'){
          printf(" 🥕 \n");
        
        }
    
    }
  }
if(verif_quick==0){
  printf("L'échange de squares ne créé pas de colonne ou de ligne de trois ou plus veuillez entrer un échange correct\n");
}
}while(verif_quick==0);  //vérifitot pour savoir si un alignement ligne/colonne de >=3 est ok
for (i = 0; i < size; i++) {
    for (k = 0; k < size; k++) {
    tab[i][k].character = tabcopie[i][k].character;
    tab[i][k].variable = tabcopie[i][k].variable;
    }
}


    
  


 

}


///////

