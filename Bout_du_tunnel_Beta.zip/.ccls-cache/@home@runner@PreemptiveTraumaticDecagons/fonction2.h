#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h> //pour les booléens

#define COLOR(X) "\x1b["X"m"    //macro pour ajouter la couleur facilement, le X est l'emplacement du code couleur, au forma "nombre"
typedef struct square_table {
    char character;
    bool variable;
    int different;
} square_table;

void Displaymoji(square_table tab[][20],int size);

bool detect_mark(square_table tab[][20],int size,bool verif_quick);

void move_left(square_table tab[][20],int size);



void empty_buffer();

void exchange(square_table tab[][20],int size);

