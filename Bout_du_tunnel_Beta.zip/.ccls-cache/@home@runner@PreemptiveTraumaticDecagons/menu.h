#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h> //pour les booléens
#include "fonction.h"

#define SAMPLE_RATE 44100   // Fréquence d'échantillonnage en Hz
#define AMPLITUDE 0.5       // Amplitude du signal


void setting_parameters();

void Home_menu();