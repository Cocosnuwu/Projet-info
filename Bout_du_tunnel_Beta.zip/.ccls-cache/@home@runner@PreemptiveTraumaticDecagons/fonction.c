#include "fonction2.h"

typedef struct {
    char nickname[20];
    int timeplay;
    long score;
} Player;

typedef struct {
    Player subplayer[10];
} Ranking;

Ranking SavePlayer(Ranking rank, Player newplayer) {
    int i, j;

    FILE *Scorefile = fopen("scores.txt", "a+");  // Ouvre le fichier en mode append et lecture

    if (Scorefile != NULL) {
        Player highScores[11];
        int numScores = 0;

        // Lit le fichier de scores pour trouver les high scores actuels
        while (fscanf(Scorefile, "%s %d %ld\n", highScores[numScores].nickname, &highScores[numScores].timeplay,&highScores[numScores].score) != EOF && numScores < 10) {
            numScores++;
        }

        // Ajoute le nouveau joueur à la liste des high scores
        highScores[numScores] = newplayer;
        numScores++;

        // Trie le tableau de high scores
        for (i = 0; i < numScores - 1; i++) {
            for (j = i + 1; j < numScores; j++) {
                if (highScores[j].score > highScores[i].score) {
                    Player temp = highScores[i];
                    highScores[i] = highScores[j];
                    highScores[j] = temp;
                } else if (highScores[j].score == highScores[i].score && highScores[j].timeplay < highScores[i].timeplay) {
                    Player temp = highScores[i];
                    highScores[i] = highScores[j];
                    highScores[j] = temp;
                }
            }
        }

        // Réinitialise le fichier en mode écriture
        freopen("scores.txt", "w", Scorefile);

        if (Scorefile != NULL) {
            for (i = 0; i < numScores; i++) {
                fprintf(Scorefile, "%s %d %ld\n", highScores[i].nickname, highScores[i].timeplay, highScores[i].score);
            }

            fclose(Scorefile);  // Ferme le fichier en mode écriture
        }

        // Met à jour le classement dans la structure Ranking
        for (i = 0; i < 10; i++) {
            if (i < numScores) {
                rank.subplayer[i] = highScores[i];
            } else {
                strcpy(rank.subplayer[i].nickname, "");
                rank.subplayer[i].timeplay = 0;
                rank.subplayer[i].score = 0;
            }
        }
    }

    return rank;
}

void AfficherRanking(Ranking rank) {
    printf("╔════════════════════════════════════════════════╗\n");
    printf("║             Classement des scores              ║\n");
    printf("╠════════════════════════════════════════════════╣\n");

    for (int i = 0; i < 10; i++) {
        printf("║ %2d. ", i + 1);

        if (strlen(rank.subplayer[i].nickname) > 0) {
            printf("%-15s - ", rank.subplayer[i].nickname);
        } else {
            printf("%-15s - ", "-");
        }

        printf("%-5d - %ld ║\n", rank.subplayer[i].timeplay, rank.subplayer[i].score);
    }

    printf("╚════════════════════════════════════════════════╝\n");
}

double replacement(square_table tab[][20],int size,int different,Player score){
    int i, j, k;
    bool verif=0;
    bool verif_quick;
    int size2;
    size2=size;
    
    
    
    
    do{             // replacement de tout les caractères avec un booléen = 1 
        verif_quick=detect_mark(tab,size2,verif_quick); // vériftot ici sert à détecter si le programme detect_mark change une variable d'un caractère 
        move_left(tab,size2);
        for(i=0;i<size;i++){
            verif=0;
            for(k=0;k<size;k++){ // Génération aléatoire des caractères
                if(tab[i][k].variable==1){
                    verif=1;
                    tab[i][k].character='A'+rand()%different; //  symboles différents choisi par l'utilisateur
                    tab[i][k].variable=0; // variable à zero pour le counter
                    score.score++;
                }
            }
        }
        
    }while(verif==1 || verif_quick==1);    //le do while ici sert pour ne pas sortir de la boucle tant que un des deux booléens est égale à 1
    return score.score;
}


bool detectionblocage(square_table tab[][20],int size){         //voir annexe des cas si besoin
    int i,j,k;
    bool verifblocage;
    verifblocage=1;
    for(i=0;i<size;i++){
        for(j=0;j<size;j++){
            if((tab[i][j].character==tab[i][j+1].character)&&(j>=2&&j<=size-4&&i>=1&&i<=size-2)){
                if(tab[i][j].character==tab[i][j-2].character||tab[i][j].character==tab[i-1][j-1].character||tab[i][j].character==tab[i+1][j-1].character||tab[i][j].character==tab[i][j+3].character||tab[i][j].character==tab[i-1][j+2].character||tab[i][j].character==tab[i+1][j+2].character){   //condition  pour le cas 1
                    return 0;    
                }
            }
            
            
            if(j==0){           //pour les doubles et simples sur la gauche         
                if(i>=1&&i<=size-2){
                    if(tab[i][0].character==tab[i][size-1].character){            
                        if(tab[i][0].character==tab[i][size-3].character||tab[i][0].character==tab[i-1][size-2].character||tab[i][0].character==tab[i+1][size-2].character||tab[i][0].character==tab[i-1][1].character||tab[i][0].character==tab[i+1][1].character||tab[i][0].character==tab[i][2].character){            //cas 2
                            return 0;
                        }
                    }
                    if(tab[i][0].character==tab[i][1].character){                   
                        if(tab[i][0].character==tab[i][size-2].character||tab[i][0].character==tab[i-1][size-1].character||tab[i][0].character==tab[i+1][size-1].character||tab[i][0].character==tab[i-1][2].character||tab[i][0].character==tab[i+1][2].character||tab[i][0].character==tab[i][3].character){    //cas 3
                            return 0;
                        }
                    }
                }
            }
            if(j==size-2){      //pour les doubles sur la droite
                if(i>=1&&i<=size-2){
                    if(tab[i][size-2].character==tab[i][size-1].character){            
                        if(tab[i][size-2].character==tab[i][size-4].character||tab[i][size-2].character==tab[i-1][size-3].character||tab[i][size-2].character==tab[i+1][size-3].character||tab[i][size-2].character==tab[i-1][0].character||tab[i][size-2].character==tab[i+1][0].character||tab[i][size-2].character==tab[i][1].character){            //cas 4
                            return 0;
                        }
                    }
                }
            }
            //les quatres cotées du table pour alignement de deux en ligne
            
            
            if(i==0&&j==0){                                     //cas 5
                if(tab[0][0].character==tab[0][1].character){            
                    if(tab[0][0].character==tab[0][size-2].character||tab[0][0].character==tab[size-1][size-1].character||tab[0][0].character==tab[1][size-1].character||tab[0][0].character==tab[0][3].character||tab[0][0].character==tab[1][2].character||tab[0][0].character==tab[size-1][2].character){    
                        return 0;
                    }
                }    
            }
            
            if(i==size-1&&j==0){  //cas 6
                if(tab[size-1][0].character==tab[size-1][1].character){            
                    if(tab[size-1][0].character==tab[size-1][size-2].character||tab[size-1][0].character==tab[size-2][size-1].character||tab[size-1][0].character==tab[0][size-1].character||tab[size-1][0].character==tab[size-1][3].character||tab[size-1][0].character==tab[size-2][2].character||tab[size-1][0].character==tab[0][2].character){    
                        return 0;
                    }
                }    
            }
            
            if(i==0&&j==size-2){                                     //cas 7
                if(tab[0][size-2].character==tab[0][size-1].character){            
                    if(tab[0][size-2].character==tab[0][size-4].character||tab[0][size-2].character==tab[size-1][size-3].character||tab[0][size-2].character==tab[1][size-3].character||tab[0][size-2].character==tab[0][1].character||tab[0][size-2].character==tab[1][0].character||tab[0][size-2].character==tab[size-1][0].character){        
                        return 0;
                    }
                }    
            }
            
            if(i==size-1&&j==size-2){                                       //cas 8
                if(tab[size-1][size-2].character==tab[size-1][size-1].character){            
                    if(tab[size-1][size-2].character==tab[0][0].character||tab[size-1][size-2].character==tab[size-2][0].character||tab[size-1][size-2].character==tab[size-1][1].character||tab[size-1][size-2].character==tab[size-1][size-4].character||tab[size-1][size-2].character==tab[size-2][size-3].character||tab[size-1][size-2].character==tab[0][size-3].character){    
                        return 0;
                    }
                }
            
            }
            //cas pour le haut et le bas
            if(i==size-1&&j==size-1){           //cas 9      
                if(tab[size-1][size-1].character==tab[size-1][0].character){            
                    if(tab[size-1][size-1].character==tab[size-1][size-3].character||tab[size-1][size-1].character==tab[size-2][size-2].character||tab[size-1][size-1].character==tab[0][size-2].character||tab[size-1][size-1].character==tab[size-1][2].character||tab[size-1][size-1].character==tab[size-2][1].character||tab[size-1][size-1].character==tab[size-2][1].character){ 
                        return 0;
                    } 
                }
            }
            
            if(i==0&&j==size-1){           //cas 10      
                if(tab[0][0].character==tab[0][size-1].character){            
                    if(tab[0][0].character==tab[0][size-3].character||tab[0][0].character==tab[1][size-2].character||tab[0][0].character==tab[size-1][size-2].character||tab[0][0].character==tab[0][2].character||tab[0][0].character==tab[size-1][1].character||tab[0][0].character==tab[1][1].character){ 
                        return 0;
                    } 
                }
            }
            
            
            
                    //suite à faire pour les colonnes
            
            
            if((tab[i][j].character==tab[i+1][j].character)&&(j>=1&&j<=size-2&&i>=2&&i<=size-4)){
                if(tab[i][j].character==tab[i-2][j].character||tab[i][j].character==tab[i-1][j-1].character||tab[i][j].character==tab[i-1][j+1].character||tab[i][j].character==tab[i+2][j-1].character||tab[i][j].character==tab[i+2][j+1].character||tab[i][j].character==tab[i+3][j].character){   //condition  pour le cas 11
                    return 0;
                }
            }

        
                    
            if(i==0){           //pour les doubles et simples sur la gauche         
                if(j>=1&&j<=size-2){
                    if(tab[0][j].character==tab[size-1][j].character){            
                        if(tab[0][j].character==tab[size-3][j].character||tab[0][j].character==tab[size-2][j-1].character||tab[0][j].character==tab[size-2][j+1].character||tab[0][j].character==tab[1][j-1].character||tab[0][j].character==tab[1][j+1].character||tab[0][j].character==tab[2][j].character){            //cas 12
                            return 0;
                        } 
                    }
                    if(tab[0][j].character==tab[1][j].character){                   
                        if(tab[0][j].character==tab[size-2][j].character||tab[0][j].character==tab[size-1][j-1].character||tab[0][j].character==tab[size-1][j+1].character||tab[0][j].character==tab[2][j-1].character||tab[0][j].character==tab[2][j+1].character||tab[0][j].character==tab[3][j].character){    //cas 13
                            return 0;
                        }
                    }
                }
            }
            if(i==size-2){                        //cas 14 
                if(j>=1&&j<=size-2){
                    if(tab[size-2][j].character==tab[size-1][j].character){            
                        if(tab[size-2][j].character==tab[size-4][j].character||tab[size-2][j].character==tab[size-3][j-1].character||tab[size-2][j].character==tab[size-3][j+1].character||tab[size-2][j].character==tab[0][j-1].character||tab[size-2][j].character==tab[0][j+1].character||tab[size-2][j].character==tab[1][j].character){
                            return 0;
                        }
                    }
                }
            }
            if(i==0&&j==0){                             //cas 15
                if(tab[0][0].character==tab[1][0].character){            
                    if(tab[0][0].character==tab[size-2][0].character||tab[0][0].character==tab[size-1][1].character||tab[0][0].character==tab[size-1][size-1].character||tab[0][0].character==tab[3][0].character||tab[0][0].character==tab[2][1].character||tab[0][0].character==tab[2][size-1].character){    
                        return 0;
                    }
                }
            }
            
            
            if(i==0&&j==size-1){                  //cas 16
                if(tab[0][size-1].character==tab[1][size-1].character){            
                    if(tab[0][size-1].character==tab[size-2][size-1].character||tab[0][size-1].character==tab[size-1][size-2].character||tab[0][size-1].character==tab[size-1][0].character||tab[0][size-1].character==tab[3][size-1].character||tab[0][size-1].character==tab[2][size-2].character||tab[0][size-1].character==tab[2][0].character){            
                        return 0;
                    }
                }
            }
            
            
            if(i==size-2&&j==0){                  
                if(tab[size-2][0].character==tab[size-1][0].character){            //cas 17
                    if(tab[size-2][0].character==tab[size-4][0].character||tab[size-2][0].character==tab[size-3][1].character||tab[size-2][0].character==tab[size-3][size-1].character||tab[size-2][0].character==tab[0][1].character||tab[size-2][0].character==tab[0][size-1].character||tab[size-2][0].character==tab[1][0].character){   
                        return 0;
                    }
                }
            }
            
            if(i==size-2&&j==size-1){                  
                if(tab[size-2][size-1].character==tab[size-1][size-1].character){          //cas 18  
                    if(tab[size-2][size-1].character==tab[size-4][size-1].character||tab[size-2][size-1].character==tab[size-3][size-2].character||tab[size-2][size-1].character==tab[size-3][0].character||tab[size-2][size-1].character==tab[0][0].character||tab[size-2][size-1].character==tab[0][size-2].character||tab[size-2][size-1].character==tab[1][size-1].character){  
                        return 0;
                    }
                }
            }
            
            if(i==size-1&&j==size-1){                  
                if(tab[size-1][size-1].character==tab[0][size-1].character){        //cas 19    
                    if(tab[size-1][size-1].character==tab[size-3][size-1].character||tab[size-1][size-1].character==tab[size-2][size-2].character||tab[size-1][size-1].character==tab[size-2][0].character||tab[size-1][size-1].character==tab[1][0].character||tab[size-1][size-1].character==tab[1][size-2].character||tab[size-1][size-1].character==tab[2][size-1].character){         
                        return 0;
                    }
                }
            }
            
            if(i==0&&j==0){                  
                if(tab[0][0].character==tab[size-1][0].character){     //cas 20       
                    if(tab[0][0].character==tab[size-3][0].character||tab[0][0].character==tab[size-2][size-1].character||tab[0][0].character==tab[size-2][1].character||tab[0][0].character==tab[1][1].character||tab[0][0].character==tab[1][size-1].character||tab[0][0].character==tab[2][0].character){   
                        return 0;
                    }
                }
            }
            
        }
    }
    return 1;
}

///////////////////////////////////////////////////////////////////////////////////




void SaveScore(Player newScore){
  FILE *Scorefile = fopen("scores.txt", "a");  // Ouvre le fichier et fait des ajouts à la fin (type "a")
    
    if (Scorefile == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        
    } else {
        fprintf(Scorefile, "%ld\n", newScore.score);
        fclose(Scorefile);
        printf("Score sauvegardé avec succès.\n");
  }
}


// Chargement de la sauvegarde
void load_save(int size, int different, Player fulltimeplay, square_table tab[][20]) {

  FILE* save = fopen("save_file.txt", "r");               // Ouverture du fichier de sauvegarde en mode écriture
    if (save == NULL) {                                      // Message erreur si aucun fichier de sauvegarde détecté
    printf("Erreur : Problème pour ouvrir la sauvegarde");
    //fprintf(save, "Score : %ld\n", score);
    }

  fscanf(save, "Tab size : %d\n", &size);                  //Lecture de la taille du tableau
  fscanf(save, "Nbr of different(s) possible symbols : %d\n", &different);       //Lecture du nombre de symboles différents
  fscanf(save, "Timer : %d\n", &fulltimeplay.timeplay);                //Lecture du temps
  
  
  for (int i=0; i < size; i++) {
    for (int k=0; k < size; k++) {
      
      fscanf(save, "%c", &tab[i][k].character);              //Lecture des cases du tableau
    }
  
  }

  fclose(save);               // Fermeture du fichier une fois écriture terminée
  printf("\x1b[32mSauvegarde chargée avec succès !\n");
  printf(COLOR("%d"), 0);
}




void auto_save(int size, int different, Player fulltimeplay, square_table tab[][20]) {
  
  FILE* save = fopen("save_file.txt", "w");               // Ouverture du fichier de sauvegarde en mode écriture
    if (save == NULL) {                                      // Message erreur si aucun fichier de sauvegarde détecté
    printf("Erreur : Problème pour ouvrir la sauvegarde");
    //fprintf(save, "Score : %ld\n", score);
    }

  fprintf(save, "Tab size : %d\n", size);
  fprintf(save, "Nbr of different(s) possible symbols : %d\n", different);
  fprintf(save, "Timer : %d\n", fulltimeplay.timeplay);
  
  for (int i=0; i < size; i++) {
    for (int k=0; k < size; k++) {
      
      fprintf(save, "%c", tab[i][k].character);
    }
  
  }

  fclose(save);               // Fermeture du fichier une fois écriture terminée
  printf("\x1b[32mSauvegarde effectuée avec succès !\n");
  printf(COLOR("%d"), 0);
}





void resume_game() {
  Ranking rankr;
  Player newplayer2;
  Player fulltimeplay;
  int size, different;
  bool verifblocage;

  FILE *Scorefile = fopen("scores.txt", "r");  // Ouvre le fichier et fait des ajouts à la fin (type "a")

  if (Scorefile == NULL) {
    printf("Erreur lors de l'ouverture du fichier.\n");
  } else {
    fscanf(Scorefile, "%ld", &newplayer2.score);
    fclose(Scorefile);
  }

  printf("Score chargé avec succès. Score actuel : %ld\n", newplayer2.score);

  square_table tab[20][20]; // Définition du tableau

  FILE* save = fopen("save_file.txt", "r");               // Ouverture du fichier de sauvegarde en mode lecture
  if (save == NULL) {                                      // Message erreur si aucun fichier de sauvegarde détecté
    printf("Erreur : Problème pour ouvrir la sauvegarde.\n");
    return;
  }

  fscanf(save, "Tab size : %d\n", &size);
  fscanf(save, "Nbr of different(s) possible symbols : %d\n", &different);
  fscanf(save, "Timer : %d\n", &fulltimeplay.timeplay);
  for (int i = 0; i < size; i++) {
    for (int k = 0; k < size; k++) {
      fscanf(save, " %c", &tab[i][k].character);     // Lecture des données du tableau dans le fichier sauvegarde
      tab[i][k].variable = 0;
    }
  }

  fclose(save);   // Fermeture du fichier une fois écriture terminée
  
  Displaymoji(tab, size);        //début du jeu
  replacement(tab, size, different, newplayer2);
  SaveScore(newplayer2);
      do{ 
    printf("Votre score est de : %ld \n",newplayer2.score);
    auto_save(size, different, fulltimeplay, tab);
    
  
    
    printf("Votre score est de : %ld \n",newplayer2.score);                                     
    Displaymoji(tab, size);        //affichage des emojis
    exchange(tab,size);            //échange
    newplayer2.score=replacement(tab, size,different,newplayer2);
    verifblocage=detectionblocage(tab,size);
    auto_save(size, different, fulltimeplay, tab);
    SaveScore(newplayer2);
    
    }while(verifblocage==0);
    Displaymoji(tab, size);
    rankr = SavePlayer(rankr, newplayer2);
    AfficherRanking(rankr);
    printf("c'est terminé plus aucun mouvement n'est possible\nvotre score final est de %ld",newplayer2.score);
}





