#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h> //pour les booléens

#include "fonction2.h"

typedef struct {
    char nickname[20];
    int timeplay;
    long score;
} Player;

typedef struct {
    Player subplayer[10];
} Ranking;

Ranking SavePlayer(Ranking rank, Player newplayer);

void AfficherRanking(Ranking rank);


double replacement(square_table tab[][20],int size,int different,Player score);

bool detectionblocage(square_table tab[][20],int size);

void SaveScore(Player newScore);


void auto_save(int size, int different, square_table tab[][20]);


void resume_game();