

#include "fonction.h"
typedef struct {
char player[50];
long score;
} Score;

Score score;


void setting_parameters();

void Home_menu();
