#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <stdbool.h> //pour les booléens
#include <string.h>


#define COLOR(X) "\x1b["X"m"    //macro pour ajouter la couleur facilement, le X est l'emplacement du code couleur, au forma "nombre"
typedef struct square_table {
    char character;
    bool variable;
    int different;
} square_table;

typedef struct {
char player[50];
long score;
} Score;

Score score;

void Displaymoji(square_table tab[][20],int size);

bool detect_mark(square_table tab[][20],int size,bool verif_quick);

void move_left(square_table tab[][20],int size);

double replacement(square_table tab[][20],int size,int different,Score score);

void empty_buffer();

void exchange(square_table tab[][20],int size);

bool detectionblocage(square_table tab[][20],int size);

void SaveScore(Score newScore);

void SaveHighScore(Score newscore);

void auto_save(int size, int different, square_table tab[][20]);

void load_save();

void resume_game();